package com.springbootinterview.demo.SpringBootInterviewPreparation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootInterviewPreparationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootInterviewPreparationApplication.class, args);
	}

}
