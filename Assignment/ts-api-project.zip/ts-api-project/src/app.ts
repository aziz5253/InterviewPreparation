interface ApiUser {
  id: number;
  name: string;
  email: string;
}

async function fetchUsers(): Promise<void> {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/users");
    const users: ApiUser[] = await response.json();

    const tableBody = document.querySelector("#userTable tbody");

    if (!tableBody) return;

    users.forEach(user => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
      `;

      tableBody.appendChild(row);
    });

  } catch (error) {
    console.error("Error fetching users:", error);
  }
}

fetchUsers();
