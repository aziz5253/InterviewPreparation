package com.inventory.serviceDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceDetailsApplication.class, args);
	}

}
