package com.inventory.serviceDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
